import java.io.IOException;

class Registre {
    public static void main(String[] args) throws IOException, InterruptedException {
        TaskRegistreSolver taskRegistreSolver = new TaskRegistreSolver();
        taskRegistreSolver.solve();
    }
}