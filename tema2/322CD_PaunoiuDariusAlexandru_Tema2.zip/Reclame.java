import java.io.IOException;

class Reclame {
    public static void main(String[] args) throws IOException, InterruptedException {
        TaskReclameSolver taskReclameSolver = new TaskReclameSolver();
        taskReclameSolver.solve();
    }
}