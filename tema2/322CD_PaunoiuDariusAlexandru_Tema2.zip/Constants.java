public final class Constants {

    public static final String ORACLE_INPUT = "sat.cnf";
    public static final String ORACLE_OUTPUT = "sat.sol";
    public static final String ORACLE_TRUE_ANS = "True";
    public static final String ORACLE_FALSE_ANS = "False";
    public static final String ORACLE_CNF_PROBLEM = "p cnf";
    public static final String ORACLE_CLAUSE_END = "0";






    
}
