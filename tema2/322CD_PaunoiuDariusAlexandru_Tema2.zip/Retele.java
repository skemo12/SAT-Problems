import java.io.IOException;

class Retele {

    public static void main(String[] args) throws IOException, InterruptedException {
        TaskReteleSolver taskReteleSolver = new TaskReteleSolver();
        taskReteleSolver.solve();
    }
}